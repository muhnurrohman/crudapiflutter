import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'adddata.dart';
import 'detailpage.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  //buat function get data
  Future<List>? getData() async {
    final response = await http.get(
      Uri.parse(
        "http://172.16.0.207/api_sekolah/pd/tampil_akun.php",
      ),
    );
    //print(response.body);
    return json.decode(response.body);
  }

  @override
  void initState() {
    getData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Peserta Didik'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          //untuk redirect ke page addData
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => const AddData(),
            ),
          );
        },
        child: const Icon(
          Icons.add,
        ),
      ),
      body: FutureBuilder<List>(
        future: getData(),
        builder: (context, snapshot) {
          // ignore: avoid_print
          if (snapshot.hasError) print(snapshot.error);
          return snapshot.hasData
              ? ItemList(list: snapshot.data)
              : const Center(
                  child: Text('Gagal tampil'),
                );
        },
      ),
    );
  }
}

// ignore: must_be_immutable
class ItemList extends StatelessWidget {
  List? list;
  ItemList({Key? key, this.list}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: list == null ? 0 : list!.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            child: Card(
              child: ListTile(
                //ini untuk klik data menampilkan ke event tampil, edit atau hapus
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) {
                        //print(list);
                        // return Container();

                        return DetailPage(list: list, index: index);
                      },
                    ),
                  );
                },
                title: Text(list![index]['name']),
                leading: const Icon(
                  Icons.widgets,
                ),
                subtitle: Text("Email :${list![index]['email']}"),
              ),
            ),
          );
        });
  }
}
