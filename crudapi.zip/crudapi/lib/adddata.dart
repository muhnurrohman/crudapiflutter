// ignore_for_file: prefer_final_fields, duplicate_ignore

import 'package:crudapi/dashboard.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AddData extends StatefulWidget {
  const AddData({Key? key}) : super(key: key);

  @override
  _AddDataState createState() => _AddDataState();
}

// ignore: duplicate_ignore
class _AddDataState extends State<AddData> {
  //deklarasikan form dulu
  // ignore: non_constant_identifier_names, prefer_final_fields
  TextEditingController _controllerId_akun = TextEditingController();
  TextEditingController _controllerName = TextEditingController();
  TextEditingController _controllerEmail = TextEditingController();
  TextEditingController _controllerPassword = TextEditingController();

  //function add data
  void addData() async {
    try {
      var url = "http://172.16.3.51//api_sekolah/pd/registrasi_akun.php";
      var response = await http.post(Uri.parse(url), body: {
        "id_akun": _controllerId_akun.text,
        "name": _controllerName.text,
        "email": _controllerEmail.text,
        "password": _controllerPassword.text,
      });
      if (response.statusCode == 200) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => const Dashboard(),
          ),
        );
      }
    } catch (e) {
      // ignore: avoid_print
      print('Error,$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(
          10.0,
        ),
        child: ListView(
          children: [
            Column(
              children: [
                TextField(
                  controller: _controllerId_akun,
                  decoration: const InputDecoration(
                    hintText: "Id_Akun",
                    labelText: "Id_Akun",
                  ),
                ),
                TextField(
                  controller: _controllerName,
                  decoration: const InputDecoration(
                    hintText: "Name",
                    labelText: "Name",
                  ),
                ),
                TextField(
                  controller: _controllerEmail,
                  decoration: const InputDecoration(
                    hintText: "Email",
                    labelText: "Email",
                  ),
                ),
                TextField(
                  controller: _controllerPassword,
                  decoration: const InputDecoration(
                    hintText: "Password",
                    labelText: "Password",
                  ),
                ),
                const SizedBox(
                  height: 10.0,
                ),
                ElevatedButton(
                  onPressed: () {
                    addData();
                  },
                  child: const Text('Save'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
