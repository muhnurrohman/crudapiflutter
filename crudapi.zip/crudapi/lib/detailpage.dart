import 'package:crudapi/dashboard.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'editpage.dart';

// ignore: must_be_immutable
class DetailPage extends StatefulWidget {
  List? list;
  int index;
  DetailPage({Key? key, this.list, required this.index}) : super(key: key);

  @override
  _DetailPageState createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  //function delete
  void deleteData() async {
    await http.post(
        Uri.parse(
          "http://172.16.3.51/api_sekolah/pd/hapus_akun.php",
        ),
        body: {
          'id': widget.list![widget.index]['id'].toString(),
        });
  }

  //function confirmation delete data
  void confirm() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: Text(
            'Apakah anda yakin untuk delete ? ${widget.list![widget.index]['name']}',
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                //delete function
                deleteData();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const Dashboard(),
                  ),
                );
              },
              child: const Icon(Icons.check_circle),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
              ),
            ),
            ElevatedButton(
              onPressed: () {
                //non redirect
                Navigator.of(context).pop();
              },
              child: const Icon(
                Icons.cancel,
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // print(widget.list![widget.index]['name']);
    // return Container();
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          widget.list![widget.index]['name'],
        ),
      ),
      body: SizedBox(
        height: 200.0,
        child: Card(
          elevation: 5.0,
          margin: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 16.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
          child: Center(
            child: Column(
              children: [
                Text(
                  widget.list![widget.index]['name'],
                  style: const TextStyle(
                    fontSize: 20.0,
                  ),
                ),
                Text(
                  "Id Akun:${widget.list![widget.index]['id_akun']}",
                  style: const TextStyle(fontSize: 18.0),
                ),
                Text(
                  "Name:${widget.list![widget.index]['email']}",
                  style: const TextStyle(fontSize: 18.0),
                ),
                Text(
                  "Email:${widget.list![widget.index]['email']}",
                  style: const TextStyle(fontSize: 18.0),
                ),
                Text(
                  "Password:${widget.list![widget.index]['password']}",
                  style: const TextStyle(fontSize: 18.0),
                ),
                const SizedBox(
                  height: 10.0,
                ),
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => EditPage(
                              list: widget.list,
                              index: widget.index,
                            ),
                          ),
                        );
                      },
                      child: const Text('Edit Data'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            const Color.fromARGB(255, 137, 76, 202),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        //function delete
                        confirm();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                      child: const Text('Delete'),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
