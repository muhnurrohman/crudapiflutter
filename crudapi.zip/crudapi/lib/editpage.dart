// ignore_for_file: non_constant_identifier_names

import 'package:crudapi/dashboard.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ignore: must_be_immutable
class EditPage extends StatefulWidget {
  List? list;
  int index;
  EditPage({Key? key, this.list, required this.index}) : super(key: key);

  @override
  _EditPageState createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  //deklarasi form
  TextEditingController _controllerId_akun = TextEditingController();
  TextEditingController _controllerName = TextEditingController();
  TextEditingController _controllerEmail = TextEditingController();
  TextEditingController _controllerPassword = TextEditingController();

//Function Edit Data
  void editData() async {
    // print(_controllerId_akun.text);
    // print(_controllerName.text);
    // print(_controllerEmail.text);
    // print(_controllerPassword.text);
    try {
      var url = "http://172.16.3.51//api_sekolah/pd/update_akun.php";
      var response = await http.post(Uri.parse(url), body: {
        //Menampilkan Data Yang Akan Di Edit
        "id": widget.list![widget.index]['id'],

        //Data Yang Akan Di Edit
        "id_akun": _controllerId_akun.text,
        "name": _controllerName.text,
        "email": _controllerEmail.text,
        "password": _controllerPassword.text,
      });

      if (response.statusCode == 200) {
        // print(response.body);
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => const Dashboard(),
          ),
        );
      }
    } catch (e) {
      // ignore: avoid_print
      print('Error, $e');
    }
  }

  //ambil data
  @override
  // ignore: unused_element
  void initState() {
    _controllerId_akun =
        TextEditingController(text: widget.list![widget.index]['id_akun']);
    _controllerName =
        TextEditingController(text: widget.list![widget.index]['name']);
    _controllerEmail =
        TextEditingController(text: widget.list![widget.index]['email']);
    _controllerPassword =
        TextEditingController(text: widget.list![widget.index]['password']);
    super.initState();
  }

  @override
  // ignore: unused_element
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Data'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ListView(
          children: [
            Column(
              children: [
                TextField(
                  controller: _controllerId_akun,
                  decoration: const InputDecoration(
                    hintText: "Id Akun ",
                    labelText: "Id Akun",
                  ),
                ),
                TextField(
                  controller: _controllerName,
                  decoration: const InputDecoration(
                    hintText: "Name ",
                    labelText: "Name",
                  ),
                ),
                TextField(
                  controller: _controllerEmail,
                  decoration: const InputDecoration(
                    hintText: "Email ",
                    labelText: "Email",
                  ),
                ),
                TextField(
                  controller: _controllerPassword,
                  decoration: const InputDecoration(
                    hintText: "Password ",
                    labelText: "Password",
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    editData();
                  },
                  child: const Text('Edit'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
